# The following imports are necessary
import rclpy
from rclpy.node import Node
from xarmclient import XArm

# Replace the following import with the interface this node is using
from std_msgs.msg import Float64MultiArray
from std_msgs.msg import Float64
from .wx250s_kinematics import *

# For example, service message type Kill from the package turtlesim would be imported as follows:
#
# from turtlesim.srv import Kill

# Furthermore, you can import here any Python module you plan to use in this node
import time

# The class name is up to you
class Auto_node(Node):
    def __init__(self):

        self.xarm = XArm()

        super().__init__("Auto_node")
        # Subscribers are created using interface type, topic name, callback function, and QoS setting
        # (the value of 10 can be left as is)
        self.Jsubscription = self.create_subscription(
            Float64MultiArray, "/auto_on_topic", self.listener_callback, 10
        )


        self.publisher = self.create_publisher(Float64, "/auto_finish", 10)
        timer_period = 0.1  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)

        self.auto_on = 0.0




    # Listener callback function will be called every time a message is published on the topic that this node is subscribed to
    def listener_callback(self, msg):

        self.auto_on = msg.data[1]
        
        if msg.data[0] == 0.0 and self.auto_on == 1.0:
            auto_home_pos = [0, 0, 0, 0, -90, 0]
            auto_rotate_pos = [0, 0, 0, 90, -45, 0]
            current_joint = auto_home_pos
            count = 0

            # 1-p1_adjust = [195,20,200]
            # 2-p1_down_pick = [195,20,20]
            # 3-p1_up_pick = [195,20,200]
            # 4-p1_up_place = [170,315,200]
            # 5-p1_down_place = [170,315,20]
            
            # 6-p2_adjust_1 = [170,315,200]
            # 7-p2_adjust_2 = [265,20,200]
            # 8-p2_down_pick = [265,20,20]
            # 9-p2_up_pick = [265,20,200]
            # 10-p2_up_place = [265,220,200]
            # 11-p2_down_place = [265,220,20]
            
            # l1_adjust_1 = [265,220,200]
            # l1_adjust_3 = [180,0,200]
            # l1_adjust_3 = [180,-325,200]
            # l1_down_pick = [180,-325,20]
            # l1_up_pick = [180,-325,200]
            # adjust angle here
            # l1_adjust_4 = [217,150,150]
            # l1_up_place = [217,267,150]
            # l1_down_place = [217,267,20]
            
            # p3_1_pick = [195,-80,20]
            # p3_1_place = [170,315,20]

            # p4_1_pick = [265,-80,20]
            # p4_1_place = [265,220,20]

            # l2_1_pick = [0,-285,20]
            # l2_1_place = [217,267,20]

            # p5_1_pick = [195,-180,20]
            # p5_1_place = [170,315,20]

            # p6_1_pick = [265,-180,20]
            # p6_1_place = [265,220,20]

            # l3_1_pick = [0,-285,20]
            # l3_1_place = [217,267,20]

            tower_1_pillars = [[195,20,200], [195,20,20], [195,20,200], [170,315,200], [170,315,20], [170,315,200], [265,20,200], [265,20,20], [265,20,200], [265,220,200], [265,220,20]]
            tower_1_level = [[265,220,200],[180,0,200],[180,-325,200],[180,-325,20],[180,-325,200],[217,267,150],[217,267,50]]
            #
            
            self.xarm.set_joints(auto_home_pos)

            while count != 6:
                current_joint = self.xarm.get_joints()
                count = 0
                for i in range(6):

                    if auto_home_pos[i] < (current_joint[i] + 4) and auto_home_pos[i] > (current_joint[i] - 4):
                        count = count + 1
            
            count = 0
            time.sleep(0.1)

            #

            for i in range(len(tower_1_pillars)):
                current_joint = self.xarm.get_joints()
                htm, _ = fk(current_joint)
                htm[0, 3] = tower_1_pillars[i][0]
                htm[1, 3] = tower_1_pillars[i][1]
                htm[2, 3] = tower_1_pillars[i][2]
                joint_ik = ik(current_joint, htm)

                self.xarm.set_joints(joint_ik)
                count = 0

                while count != 6:

                    current_joint = self.xarm.get_joints()
                    count = 0
                    for j in range(6):

                        if joint_ik[j] < (current_joint[j] + 4) and joint_ik[j] > (current_joint[j] - 4):
                            count = count + 1

                if i == 1 or i == 7:
                    self.xarm.grip(1)
                    time.sleep(2)


                if i == 4 or i == 10:
                    self.xarm.grip(0)
                    time.sleep(2)

            #

            for i in range(len(tower_1_level)-3):
                current_joint = self.xarm.get_joints()
                htm, _ = fk(current_joint)
                htm[0, 3] = tower_1_level[i][0]
                htm[1, 3] = tower_1_level[i][1]
                htm[2, 3] = tower_1_level[i][2]
                joint_ik = ik(current_joint, htm)

                self.xarm.set_joints(joint_ik)
                count = 0

                while count != 6:

                    current_joint = self.xarm.get_joints()
                    count = 0
                    for j in range(6):

                        if joint_ik[j] < (current_joint[j] + 4) and joint_ik[j] > (current_joint[j] - 4):
                            count = count + 1

                if i == 3:
                    self.xarm.grip(1)
                    time.sleep(2)
            count = 0

            self.xarm.set_joints(auto_rotate_pos)
            while count != 6:
                current_joint = self.xarm.get_joints()
                count = 0
                for i in range(6):

                    if auto_home_pos[i] < (current_joint[i] + 4) and auto_home_pos[i] > (current_joint[i] - 4):
                        count = count + 1
            count = 0
            time.sleep(0.1)


            for i in range(3):
                current_joint = self.xarm.get_joints()
                htm, _ = fk(current_joint)
                htm[0, 3] = tower_1_level[i+len(tower_1_level)-3][0]
                htm[1, 3] = tower_1_level[i+len(tower_1_level)-3][1]
                htm[2, 3] = tower_1_level[i+len(tower_1_level)-3][2]
                joint_ik = ik(current_joint, htm)

                self.xarm.set_joints(joint_ik)
                count = 0

                while count != 6:

                    current_joint = self.xarm.get_joints()
                    count = 0
                    for j in range(6):

                        if joint_ik[j] < (current_joint[j] + 4) and joint_ik[j] > (current_joint[j] - 4):
                            count = count + 1

                if i == 0:
                    self.xarm.grip(0)
                    time.sleep(2)









        self.auto_on = 0.0
        
        

            

            
    def timer_callback(self):
        
        message = Float64()
        if self.auto_on == 0.0:
            message.data = self.auto_on
            self.publisher.publish(message)



# The code below runs the node and should be left as is
def main(args=None):

    rclpy.init(args=args)

    node = Auto_node()
    rclpy.spin(node)
    node.destroy_node()

    rclpy.shutdown()


if __name__ == "__main__":
    main()
