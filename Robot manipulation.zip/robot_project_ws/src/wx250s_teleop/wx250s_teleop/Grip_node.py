# The following imports are necessary
import rclpy
from rclpy.node import Node
from xarmclient import XArm

# Replace the following import with the interface this node is using
from sensor_msgs.msg import Joy

# For example, service message type Kill from the package turtlesim would be imported as follows:
#
# from turtlesim.srv import Kill

# Furthermore, you can import here any Python module you plan to use in this node


# The class name is up to you
class Grip_node(Node):
    def __init__(self):

        self.xarm = XArm()

        super().__init__("grip_node")
        # Subscribers are created using interface type, topic name, callback function, and QoS setting
        # (the value of 10 can be left as is)
        self.subscription = self.create_subscription(
            Joy, "/joy", self.listener_callback, 10
        )
        self.open = 1

    # Listener callback function will be called every time a message is published on the topic that this node is subscribed to
    def listener_callback(self, msg):
        #self.get_logger().info(f"I heard: {msg.buttons[4:6]}") #uncomment for debug
        if self.open == 0 and msg.buttons[4] == 1:
            self.xarm.grip(0)
            self.open = 1
        elif self.open == 1 and msg.buttons[5] == 1:
            self.xarm.grip(1)
            self.open = 0
            




# The code below runs the node and should be left as is
def main(args=None):
    rclpy.init(args=args)

    node = Grip_node()
    rclpy.spin(node)
    node.destroy_node()

    rclpy.shutdown()


if __name__ == "__main__":
    main()
