# The following imports are necessary
import rclpy
from rclpy.node import Node
from xarmclient import XArm

# Replace the following import with the interface this node is using
from std_msgs.msg import Float64MultiArray

# For example, service message type Kill from the package turtlesim would be imported as follows:
#
# from turtlesim.srv import Kill

# Furthermore, you can import here any Python module you plan to use in this node


# The class name is up to you
class JointPTP_node(Node):
    def __init__(self):

        self.xarm = XArm()

        super().__init__("JointPTP_node")
        self.subscription = self.create_subscription(
            Float64MultiArray, "/joint_topic", self.listener_callback, 10
        )




    # Listener callback function will be called every time a message is published on the topic that this node is subscribed to
    def listener_callback(self, msg):
        joint_off = msg.data[0]
        homing = msg.data[1]
        #self.get_logger().info(f"joint_on: {joint_off}, homing: {homing}") #uncomment for debug

        if joint_off == 0 and homing == 0:
            #self.get_logger().info(f"data got: {msg.data}") #uncomment for debug
            current_joints = list(self.xarm.get_joints())
            move_joints = current_joints
            for i in range(6):
                move_joints[i] = current_joints[i] + msg.data[i+2]
            
            self.xarm.set_joints(move_joints)
            #self.get_logger().info(f"next joint: {move_joints}") #uncomment for debug
            
            




# The code below runs the node and should be left as is
def main(args=None):
    rclpy.init(args=args)

    node = JointPTP_node()
    rclpy.spin(node)
    node.destroy_node()

    rclpy.shutdown()


if __name__ == "__main__":
    main()
