# The following imports are necessary
import rclpy
from rclpy.node import Node
from xarmclient import XArm

# Replace the following import with the interface this node is using
from sensor_msgs.msg import Joy
from std_msgs.msg import Float64

# For example, service message type Kill from the package turtlesim would be imported as follows:
#
# from turtlesim.srv import Kill

# Furthermore, you can import here any Python module you plan to use in this node


# The class name is up to you
class Homing_node(Node):
    def __init__(self):

        self.xarm = XArm()

        super().__init__("homing_node")
        # Subscribers are created using interface type, topic name, callback function, and QoS setting
        # (the value of 10 can be left as is)
        self.subscription = self.create_subscription(
            Joy, "/joy", self.listener_callback, 10
        )


        self.publisher = self.create_publisher(Float64, "/homing", 10)
        timer_period = 0.1  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)

        self.home_counter = 0.0
        self.prev_state = 0.0


    # Listener callback function will be called every time a message is published on the topic that this node is subscribed to
    def listener_callback(self, msg):
        
        home_pos = [0,45,-80,0,35,0]
        self.prev_state = self.home_counter
        #self.get_logger().info(f"I heard: {msg.buttons[4:6]}") #uncomment for debug
        if msg.buttons[10] == 1:
            count = 0
            prev_count = 0
            while count < 6:
                self.xarm.home()
                current_joint = self.xarm.get_joints()
                count = 0
                for i in range(6):
                    
                        if home_pos[i] < (
                            current_joint[i] + 4
                        ) and home_pos[i] > (current_joint[i] - 4):
                            count = count + 1
                #self.get_logger().info(f"count: {count}") #uncomment for debug
            
            self.home_counter = self.home_counter + 1

            
    def timer_callback(self):
        
        message = Float64()
        if self.home_counter != self.prev_state:
            message.data = 0.0
            self.publisher.publish(message)



# The code below runs the node and should be left as is
def main(args=None):
    rclpy.init(args=args)

    node = Homing_node()
    rclpy.spin(node)
    node.destroy_node()

    rclpy.shutdown()


if __name__ == "__main__":
    main()
