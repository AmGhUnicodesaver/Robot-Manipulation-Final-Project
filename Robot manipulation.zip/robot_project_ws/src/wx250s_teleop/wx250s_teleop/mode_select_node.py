# The following imports are necessary
import rclpy
from rclpy.node import Node
from xarmclient import XArm

# Replace the following import with the interface this node is using
from std_msgs.msg import Float64MultiArray
from std_msgs.msg import Float64
from sensor_msgs.msg import Joy

# For example, service message type Kill from the package turtlesim would be imported as follows:
#
# from turtlesim.srv import Kill

# Furthermore, you can import here any Python module you plan to use in this node


# The class name is up to you
class Mode_select_node(Node):
    def __init__(self):
        super().__init__("mode_select_node")

        self.xarm = XArm()

        #joy subscriber
        self.Jsubscription = self.create_subscription(
            Joy, "/joy", self.listener_callback, 10
        )

        #home subscriber
        self.Hsubscription = self.create_subscription(
            Float64, "/homing", self.homing_callback, 10
        )

        #auto subscriber
        self.Asubscription = self.create_subscription(
            Float64, "/auto_finish", self.auto_callback, 10
        )

        #joint publisher
        self.Jpublisher = self.create_publisher(Float64MultiArray, "/joint_topic", 10)
        timer_period = 0.1  # seconds
        self.timer = self.create_timer(timer_period, self.joint_callback)

        #cartesian publisher
        self.Cpublisher = self.create_publisher(Float64MultiArray, "/cartesian_topic", 10)
        timer_period = 0.1  # seconds
        self.timer = self.create_timer(timer_period, self.cartesian_callback)

        #auto publisher
        self.Apublisher = self.create_publisher(Float64MultiArray, "/auto_on_topic", 10)
        timer_period = 0.1 # seconds
        self.timer = self.create_timer(timer_period, self.auto_on_callback)
        
        # Define variables used by the node here, for example a simple counter
        self.joint_is_0_cart_is_1 = 0
        self.dpad_ver = 0
        self.dpad_hor = 0
        self.L3_ver = 0
        self.L3_hor = 0
        self.R3_ver = 0
        self.R3_hor = 0
        self.going_home = 0.0
        self.home_button = 0
        self.auto = 0
        self.auto_on = 0.0
        self.press = 0


    def listener_callback(self, msg):
        if msg.buttons[8] == 1:
            self.joint_is_0_cart_is_1 = 1
        elif msg.buttons[9] == 1:
            self.joint_is_0_cart_is_1 = 0
        #self.get_logger().info(f"joint_is_0_cart_is_1: {self.joint_is_0_cart_is_1}") #uncomment for debug

        self.dpad_hor = msg.axes[6]
        self.dpad_ver = msg.axes[7]
        self.L3_hor = msg.axes[0]
        self.L3_ver = msg.axes[1]
        self.R3_hor = msg.axes[3]
        self.R3_ver = msg.axes[4]
        self.home_button = msg.buttons[10]
        self.auto = msg.buttons[0]

        if self.home_button == 1:
            self.going_home = 1.0

        
        

        #self.get_logger().info(f"dpad_hor: {self.dpad_hor}\ndpad_ver: {self.dpad_ver}\nL3_hor: {self.L3_hor}\nL3_ver: {self.L3_ver}\nR3_hor: {self.R3_hor}\nR3_ver: {self.R3_ver}\n ") #uncomment for debug

    def homing_callback(self, msg):
        self.going_home = msg.data

    def auto_callback(self, msg):
        self.auto_on = msg.data


    def joint_callback(self):

        joint_message = Float64MultiArray()
        
        #self.get_logger().info(f"homing: {self.going_home}, mode: {self.joint_is_0_cart_is_1}") #uncomment for debug

        if self.going_home == 0.0 and self.auto_on == 0.0:
            if self.joint_is_0_cart_is_1 == 0:
                joint_1 = round(self.R3_hor * 3, 1)
                joint_2 = -round(self.R3_ver * 3, 1)
                joint_3 = round(self.L3_ver * 3, 1)
                joint_4 = -round(self.L3_hor * 3, 1)
                joint_5 = round(self.dpad_ver * 3, 1)
                joint_6 = -round(self.dpad_hor * 3, 1)
            
            
                joint_message.data = [self.joint_is_0_cart_is_1,self.going_home,joint_1,joint_2,joint_3,joint_4,joint_5,joint_6]
                #self.get_logger().info(f"joint_data: {joint_message.data}") #uncomment for debug
                self.Jpublisher.publish(joint_message)

        

    def cartesian_callback(self):
        cartesian_message = Float64MultiArray()

        if self.going_home == 0.0 and self.auto_on == 0.0:
            if self.joint_is_0_cart_is_1 == 1:
                x = round(self.R3_ver *5, 1)
                y = round(self.R3_hor *5, 1)
                z = round(self.L3_ver * 3, 1)
            
            
                cartesian_message.data = [self.joint_is_0_cart_is_1,self.going_home,x,y,z]
                #self.get_logger().info(f"joint_data: {cartesian_message.data}") #uncomment for debug
                self.Cpublisher.publish(cartesian_message)
    


    def auto_on_callback(self):

        auto_message = Float64MultiArray()
        

        if self.auto == 1 and self.auto_on == 0.0 and self.press == 0:
            self.auto_on = 1.0
            #self.get_logger().info(f"x pressed: {self.auto}") #uncomment for debug
            self.press = 1

            #self.get_logger().info(f"button press: {self.auto_on}") #uncomment for debug
            auto_message.data = [self.going_home, self.auto_on]
            #self.get_logger().info(f"auto_data: {auto_message.data}") #uncomment for debug
            self.Apublisher.publish(auto_message)


        elif self.auto == 0:
            self.press = 0

        



# The code below runs the node and should be left as is
def main(args=None):
    rclpy.init(args=args)

    node = Mode_select_node()
    rclpy.spin(node)
    node.destroy_node()

    rclpy.shutdown()


if __name__ == "__main__":
    main()
