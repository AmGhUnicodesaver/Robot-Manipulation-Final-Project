# The following imports are necessary
import rclpy
from rclpy.node import Node
from xarmclient import XArm

# Replace the following import with the interface this node is using
from std_msgs.msg import Float64MultiArray
from .wx250s_kinematics import *

# For example, service message type Kill from the package turtlesim would be imported as follows:
#
# from turtlesim.srv import Kill

# Furthermore, you can import here any Python module you plan to use in this node


# The class name is up to you
class CartesianPTP_node(Node):
    def __init__(self):

        self.xarm = XArm()

        super().__init__("CartesianPTP_node")
        self.subscription = self.create_subscription(
            Float64MultiArray, "/cartesian_topic", self.listener_callback, 10
        )




    # Listener callback function will be called every time a message is published on the topic that this node is subscribed to
    def listener_callback(self, msg):
        joint_off = msg.data[0]
        homing = msg.data[1]
        #self.get_logger().info(f"joint_on: {joint_on}, homing: {homing}") #uncomment for debug

        if joint_off == 1 and homing == 0:
            #self.get_logger().info(f"data got: {msg.data}") #uncomment for debug
            current_joints = list(self.xarm.get_joints())
            htm, _ = fk(current_joints)
            
            
            htm[0, 3] = htm[0, 3] + msg.data[2]
            htm[1, 3] = htm[1, 3] + msg.data[3]
            htm[2, 3] = htm[2, 3] + msg.data[4]

            out_ik = ik(current_joints,htm)
            self.xarm.set_joints(out_ik)

            #self.get_logger().info(f"next joint: {move_joints}") #uncomment for debug
            
            




# The code below runs the node and should be left as is
def main(args=None):
    rclpy.init(args=args)

    node = CartesianPTP_node()
    rclpy.spin(node)
    node.destroy_node()

    rclpy.shutdown()


if __name__ == "__main__":
    main()
