// generated from rosidl_generator_c/resource/idl.h.em
// with input from wx250s_interface:action/JointPTP.idl
// generated code does not contain a copyright notice

#ifndef WX250S_INTERFACE__ACTION__JOINT_PTP_H_
#define WX250S_INTERFACE__ACTION__JOINT_PTP_H_

#include "wx250s_interface/action/detail/joint_ptp__struct.h"
#include "wx250s_interface/action/detail/joint_ptp__functions.h"
#include "wx250s_interface/action/detail/joint_ptp__type_support.h"

#endif  // WX250S_INTERFACE__ACTION__JOINT_PTP_H_
