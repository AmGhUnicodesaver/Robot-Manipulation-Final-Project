// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef WX250S_INTERFACE__ACTION__JOINT_PTP_HPP_
#define WX250S_INTERFACE__ACTION__JOINT_PTP_HPP_

#include "wx250s_interface/action/detail/joint_ptp__struct.hpp"
#include "wx250s_interface/action/detail/joint_ptp__builder.hpp"
#include "wx250s_interface/action/detail/joint_ptp__traits.hpp"
#include "wx250s_interface/action/detail/joint_ptp__type_support.hpp"

#endif  // WX250S_INTERFACE__ACTION__JOINT_PTP_HPP_
