# The following imports are necessary
import rclpy
from rclpy.node import Node
from xarmclient import XArm

# Replace the following import with the interface this node is using
from std_srvs.srv import SetBool

# For example, service message type Kill from the package turtlesim would be imported as follows:
#
# from turtlesim.srv import Kill

# Furthermore, you can import here any Python module you plan to use in this node


# The class name is up to you
class MyClassName(Node):
    def __init__(self):

        self.xarm = XArm()

        super().__init__("grip_node")
        # Service servers are created using interface type, service name and callback function

        self.service = self.create_service(SetBool, "grip", self.grip_callback)

    # Service callback will be called when the server receives a request
    # Note that the request and response variables are already created and just need to be filled with data
    def grip_callback(self, request, response):
        if request.data == True:
            self.xarm.grip(1)
        elif request.data == False:
            self.xarm.grip(0)
        return response


# The code below runs the node and should be left as is
def main(args=None):
    rclpy.init(args=args)

    node = MyClassName()
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == "__main__":
    main()
