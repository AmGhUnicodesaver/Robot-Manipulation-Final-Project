# The following imports are necessary
import threading
import rclpy
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node

# Replace the following import with the interface this node is using
from xarmclient import XArm
from wx250s_pose_interface.action import SetCartesianPTP
from .wx250s_kinematics import *

# You can import here any Python module you plan to use in this node
import time
import math


# The class name is up to you
class MyClassName(Node):
    #    """Minimal action server that processes one goal at a time."""

    def __init__(self):

        self.xarm = XArm()

        super().__init__("cartesian_ptp_node")
        self.goal_handle = None
        self.goal_lock = threading.Lock()
        # Action servers are created using interface type, action name and multiple callback functions
        self.action_server = ActionServer(
            self,
            SetCartesianPTP,
            "set_cartesian_ptp",
            execute_callback=self.execute_callback,
            goal_callback=self.goal_callback,
            handle_accepted_callback=self.handle_accepted_callback,
            cancel_callback=self.cancel_callback,
            callback_group=ReentrantCallbackGroup(),
        )
        self.final_joints =[]
    def destroy(self):
        self.action_server.destroy()
        super().destroy_node()

    # This function is called whenever new goal request is received
    def goal_callback(self, goal_request):
        # Accept or reject a client request to begin an action
        test_ik = []
        try:
            segment_distance = 60
            x = goal_request.x
            y = goal_request.y
            z = goal_request.z
            present_joints = self.xarm.get_joints()
            htm, _ = fk(present_joints)
            htm_test,_ = fk(present_joints)
            present_position = htm[:3, 3]
            dst = SetCartesianPTP.Feedback()
            distance = math.sqrt(
                (x - present_position[0]) ** 2
                + (y - present_position[1]) ** 2
                + (z - present_position[2]) ** 2
            )
            diff_num = math.ceil(distance / segment_distance)
            # Get the request positions


            final = [x,y,z]


            # Perform inverse kinematics of each segment

            # remember htm is in mm
            for i in range(1, diff_num + 1):
      
                htm[0, 3] = htm[0, 3] + (((x - htm[0, 3]) / diff_num) * i)
                htm[1, 3] = htm[1, 3] + (((y - htm[1, 3]) / diff_num) * i)
                htm[2, 3] = htm[2, 3] + (((z - htm[2, 3]) / diff_num) * i)

                test_ik = ik(present_joints, htm)
                
                self.get_logger().info(f"test_ik: {test_ik}\n")
                self.get_logger().info(f"test_ik: {htm}\n")
                if test_ik is None:
                    self.get_logger().info(f"NONE: {test_ik}\n")
                    return GoalResponse.REJECT
                if self.xarm.is_goal_valid(test_ik) != 0:
                    self.get_logger().info(f"invalid: {test_ik}\n")
                    return GoalResponse.REJECT
                htm, _ = fk(test_ik)
        except Exception as e:
                self.get_logger().info(f"PPYTHON ERROR: {e}\n")
                return GoalResponse.REJECT
        self.final_joints = test_ik
        return GoalResponse.ACCEPT
        # return GoalResponse.REJECT

    # This function is called whenever new goal has been accepted
    def handle_accepted_callback(self, goal_handle):
        with self.goal_lock:
            # This server only allows one goal at a time
            if self.goal_handle is not None and self.goal_handle.is_active:
                self.get_logger().info("Aborting previous goal")
                # Abort the existing goal
                self.goal_handle.abort()
            self.goal_handle = goal_handle

        goal_handle.execute()

    # This function is called whenever cancel request is received
    def cancel_callback(self, goal):
        # Accept or reject a client request to cancel an action
        self.get_logger().info("Received cancel request")
        return CancelResponse.ACCEPT

    # This function is called at the start of action execution
    def execute_callback(self, goal_handle):
        self.get_logger().info("Executing goal...")

        test_ik = self.final_joints
        self.xarm.set_joints(test_ik)

        count = 0
        
        while True:
            
            feedback_msg = list(self.xarm.get_joints())
            htm, _  = fk(feedback_msg)
            # distance = math.sqrt(
            #     (x - present_position[0]) ** 2
            #     + (y - present_position[1]) ** 2
            #     + (z - present_position[2]) ** 2
            # )
            count = 0
            for i in range(6):

                if feedback_msg[i] < (
                    test_ik[i] + 4
                ) and feedback_msg[i] > (test_ik[i] - 4):
                    count = count + 1
            if count == 6:
                break
            time.sleep(0.1)


            # while count < 3:
            #     count = 0
            #     for j in range(3):
            #         if present_position[j] < (prev_position[j] + 0.5) and present_position[j] > (prev_position[j] - 0.5):
                        
            #             test_joints = self.xarm.get_joints()
            #             htm_test, _ = fk(test_joints)
            #             prev_position = htm_test[:3,3]
            #             count = count + 1
            #         self.get_logger().info(f"count: {count}\n")
                        


            
        #     self.get_logger().info(f"distance: {distance}\n")


        # self.get_logger().info(f"distance: {distance}\n")
    
        #goal_handle.feedback(distance)

        goal_handle.succeed()
        result = SetCartesianPTP.Result()
        result.success = True

        # self.get_logger().info(f"Moved to position: {result}")

        return result


def main(args=None):
    rclpy.init(args=args)

    node = MyClassName()

    # We use a MultiThreadedExecutor to handle incoming goal requests concurrently
    executor = MultiThreadedExecutor()
    rclpy.spin(node, executor=executor)

    node.destroy()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
