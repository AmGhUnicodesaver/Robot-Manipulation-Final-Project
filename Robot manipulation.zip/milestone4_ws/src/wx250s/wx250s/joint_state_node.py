# The following imports are necessary
import rclpy
from rclpy.node import Node
import math

# Replace the following import with the interface this node is using
from sensor_msgs.msg import JointState
from xarmclient import XArm

# For example, service message type Kill from the package turtlesim would be imported as follows:
#
# from turtlesim.srv import Kill

# Furthermore, you can import here any Python module you plan to use in this node


# The class name is up to you
class MyClassName(Node):
    def __init__(self):

        self.xarm = XArm()

        super().__init__("joint_state_node")
        # Publishers are created using interface type, topic name and QoS setting
        # (the value of 10 can be left as is)
        self.publisher = self.create_publisher(JointState, "joint_state", 10)
        # Publishers typically publish messages at a predefined rate
        timer_period = 0.2  # seconds
        # The timer_callback function will be called every timer_period seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)
        # Define variables used by the node here, for example a simple counter

    def timer_callback(self):
        # To publish a message, you need to create the corresponding object first
        # The name is the same as interface name (e.g., String or Kill)
        msg = JointState()
        
        
        
        current = list(self.xarm.get_joints())
        i=0
        for i in range(6):
            current[i] = current[i] * math.pi/180
        msg.position = current
        msg.name = ["joint1", "joint2", "joint3", "joint4", "joint5", "joint6"]
        self.publisher.publish(msg)
        # Logger displays formatted text in the console, useful for simple debugging
        #self.get_logger().info(f"joint state: {msg.position}")


# The code below runs the node and should be left as is
def main(args=None):
    rclpy.init(args=args)

    node = MyClassName()
    rclpy.spin(node)
    node.destroy_node()

    rclpy.shutdown()


if __name__ == "__main__":
    main()
