# The following imports are necessary
import threading
import rclpy
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node

# Replace the following import with the interface this node is using
from xarmclient import XArm
from sensor_msgs.msg import JointState
from wx250s_interface.action import JointPTP

# You can import here any Python module you plan to use in this node
import time


# The class name is up to you
class MyClassName(Node):
    #    """Minimal action server that processes one goal at a time."""

    def __init__(self):

        self.xarm = XArm()

        super().__init__("joint_ptp_node")
        self.goal_handle = None
        self.goal_lock = threading.Lock()
        # Action servers are created using interface type, action name and multiple callback functions
        self.action_server = ActionServer(
            self,
            JointPTP,
            "JointPTP",
            execute_callback=self.execute_callback,
            goal_callback=self.goal_callback,
            handle_accepted_callback=self.handle_accepted_callback,
            cancel_callback=self.cancel_callback,
            callback_group=ReentrantCallbackGroup(),
        )

    def destroy(self):
        self.action_server.destroy()
        super().destroy_node()

    # This function is called whenever new goal request is received
    def goal_callback(self, goal_request):
        # Accept or reject a client request to begin an action

        ### check if given goal is within the arms accepted limits

        for i in range(6):
            if goal_request.joint_goal[i] < 90 and goal_request.joint_goal[i] > -90:
                self.get_logger().info("Received goal request")
                return GoalResponse.ACCEPT
            else:
                return GoalResponse.REJECT

    # This function is called whenever new goal has been accepted
    def handle_accepted_callback(self, goal_handle):
        with self.goal_lock:
            # This server only allows one goal at a time
            if self.goal_handle is not None and self.goal_handle.is_active:
                self.get_logger().info("Aborting previous goal")
                # Abort the existing goal
                self.goal_handle.abort()
            self.goal_handle = goal_handle

        goal_handle.execute()

    # This function is called whenever cancel request is received
    def cancel_callback(self, goal):
        # Accept or reject a client request to cancel an action
        self.get_logger().info("Received cancel request")
        return CancelResponse.ACCEPT

    # This function is called at the start of action execution
    def execute_callback(self, goal_handle):
        self.get_logger().info("Executing goal...")

        feedback_msg = self.xarm.get_joints()
        previous_msg = feedback_msg
        Get_temp = self.xarm.get_joints()
        first_ticker = 0

    

        self.xarm.set_joints(goal_handle.request.joint_goal)
        #print(feedback_msg)
        while True:
            count = 0
            stuck = 0

            for i in range(6):

                if feedback_msg[i] < (
                    goal_handle.request.joint_goal[i] + 4
                ) and feedback_msg[i] > (goal_handle.request.joint_goal[i] - 4):
                    count = count + 1

            if  count != 6:
            
                for i in range(6):

                    if feedback_msg[i] < (previous_msg[i] + 3) and feedback_msg[i] > (
                        previous_msg[i] - 3
                    ):
                        stuck = stuck + 1

                if first_ticker > 10:

                    if stuck == 6:
                        self.get_logger().info("arm stuck")
                        self.xarm.set_joints(feedback_msg)
                        goal_handle.abort()
                        return JointPTP.Result()

            # print(f"desired position {goal_handle.request.joint_goal} \n current position {feedback_msg} \n previous position {previous_msg} \n count: {count} stuck: {stuck} stuck tick : {stuck_ticker}")

            if count == 6:
                goal_handle.succeed()
                return JointPTP.Result(success=True)
            time.sleep(0.1)
            previous_msg = feedback_msg
            feedback_msg = self.xarm.get_joints()

            first_ticker = first_ticker + 1

        #with self.goal_lock:
         #   if not goal_handle.is_active:
          #      self.get_logger().info("Goal aborted")
           #     return JointPTP.Result()

            #goal_handle.succeed()

        result = JointPTP.Result()
        result.success = True

        self.get_logger().info(f"Moved to position: {result}")

        return result


def main(args=None):
    rclpy.init(args=args)

    node = MyClassName()

    # We use a MultiThreadedExecutor to handle incoming goal requests concurrently
    executor = MultiThreadedExecutor()
    rclpy.spin(node, executor=executor)

    node.destroy()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
