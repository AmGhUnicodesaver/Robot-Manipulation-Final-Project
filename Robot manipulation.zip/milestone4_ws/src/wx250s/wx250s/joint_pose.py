# The following imports are necessary
import rclpy
from rclpy.node import Node
import math
import scipy

# Replace the following import with the interface this node is using
from geometry_msgs.msg import PoseStamped
from xarmclient import XArm
from .wx250s_kinematics import *

# For example, service message type Kill from the package turtlesim would be imported as follows:
#
# from turtlesim.srv import Kill

# Furthermore, you can import here any Python module you plan to use in this node


# The class name is up to you
class MyClassName(Node):
    def __init__(self):

        self.xarm = XArm()

        super().__init__("joint_pose")
        # Publishers are created using interface type, topic name and QoS setting
        # (the value of 10 can be left as is)
        self.publisher = self.create_publisher(PoseStamped, "pose", 10)
        # Publishers typically publish messages at a predefined rate
        timer_period = 0.2  # seconds
        # The timer_callback function will be called every timer_period seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)
        # Define variables used by the node here, for example a simple counter

    def timer_callback(self):
        # To publish a message, you need to create the corresponding object first
        # The name is the same as interface name (e.g., String or Kill)
        msg = PoseStamped()

        og_joint = list(self.xarm.get_joints())

        htm, _ = fk(og_joint)

        rotation_matrix = scipy.spatial.transform.Rotation.from_matrix(htm[:3, :3])
        quarter = rotation_matrix.as_quat()

        # self.get_logger().info(f"quat: {htm[:3, 3]}")

        msg.pose.position.x = htm[0, 3] / 1000
        msg.pose.position.y = htm[1, 3] / 1000
        msg.pose.position.z = htm[2, 3] / 1000

        msg.pose.orientation.x = quarter[0]
        msg.pose.orientation.y = quarter[1]
        msg.pose.orientation.z = quarter[2]
        msg.pose.orientation.w = quarter[3]

        msg.header.frame_id = (
            "/base"  # /base for irl and /wx250s/base_link for simulation
        )

        self.publisher.publish(msg)
        # Logger displays formatted text in the console, useful for simple debugging
        # self.get_logger().info(f"joint state: {msg.pose}")


# The code below runs the node and should be left as is
def main(args=None):
    rclpy.init(args=args)

    node = MyClassName()
    rclpy.spin(node)
    node.destroy_node()

    rclpy.shutdown()


if __name__ == "__main__":
    main()
