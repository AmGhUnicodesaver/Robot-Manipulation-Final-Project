# The following imports are necessary
import rclpy
from rclpy.node import Node

# Replace the following import with the interface this node is using
from xarmclient import XArm
from .wx250s_kinematics import *
from wx250s_pose_interface.srv import PickAndPlace

# For example, service message type Kill from the package turtlesim would be imported as follows:
#
# from turtlesim.srv import Kill

# Furthermore, you can import here any Python module you plan to use in this node
import time

# The class name is up to you
class MyClassName(Node):
    def __init__(self):
        self.xarm = XArm()
        super().__init__("pick_and_place_node")
        # Service servers are created using interface type, service name and callback function
        self.service = self.create_service(
            PickAndPlace, "pick_and_place", self.service_callback
        )

    # Service callback will be called when the server receives a request
    # Note that the request and response variables are already created and just need to be filled with data
    def service_callback(self, request, response):
        
        current_joint = self.xarm.get_joints()
        move_pos = [0, 0, 0, 0, -90, 0]
        count = 0

        xpick = request.xpick
        ypick = request.ypick
        xplace = request.xplace
        yplace = request.yplace

        pose_1 = [xpick, ypick, 20.0]
        pose_2 = [xpick, ypick, 200.0]
        pose_3 = [xplace, yplace, 200.0]
        pose_4 = [xplace, yplace, 20.0]
        pose = [pose_1, pose_2, pose_3, pose_4]
        current_joint = move_pos
        
        
        for i in range(4):
      
                
                htm, _ = fk(current_joint)
                htm[0, 3] = pose[i][0]
                htm[1, 3] = pose[i][1]
                htm[2, 3] = pose[i][2]
                test_ik = ik(current_joint, htm)

                current_joint = test_ik
                
                self.get_logger().info(f"test_ik: {test_ik}\n")
                self.get_logger().info(f"test_ik: {htm}\n")
                self.get_logger().info(f"count: {i}\n")

                if test_ik is None:
                    self.get_logger().info(f"NONE: {test_ik}\n")
                    return response
                if self.xarm.is_goal_valid(test_ik) != 0:
                    self.get_logger().info(f"invalid: {test_ik}\n")
                    return response
                htm, _ = fk(test_ik)
        
        
        
        
        
        

        self.xarm.set_joints(move_pos)
       

        while count != 6:

            current_joint = self.xarm.get_joints()
            count = 0
            for i in range(6):

                if move_pos[i] < (current_joint[i] + 4) and move_pos[i] > (current_joint[i] - 4):
                    count = count + 1
            
        count = 0
        time.sleep(0.1)

        

        for i in range(4):
            current_joint = self.xarm.get_joints()
            htm, _ = fk(current_joint)
            htm[0, 3] = pose[i][0]
            htm[1, 3] = pose[i][1]
            htm[2, 3] = pose[i][2]
            joint_ik = ik(current_joint, htm)

            self.xarm.set_joints(joint_ik)
            count = 0

            while count != 6:

                current_joint = self.xarm.get_joints()
                count = 0
                for j in range(6):

                    if joint_ik[j] < (current_joint[j] + 4) and joint_ik[j] > (current_joint[j] - 4):
                        count = count + 1
            
            if i == 0:
                self.xarm.grip(1)
                time.sleep(2)


            if i == 3:
                self.xarm.grip(0)
                time.sleep(2)
        
            response.x_current = htm[0, 3]
            response.y_current = htm[1, 3]
            response.z_current = htm[2, 3]

            # Logger displays formatted text in the console, useful for simple debugging
            self.get_logger().info(f"currently at\nx: {response.x_current}, y: {response.y_current}, z: {response.z_current}")

        self.xarm.set_joints(move_pos)

        while count != 6:

            current_joint = self.xarm.get_joints()
            count = 0
            for i in range(6):

                if move_pos[i] < (current_joint[i] + 4) and move_pos[i] > (current_joint[i] - 4):
                    count = count + 1
            
        count = 0
        time.sleep(0.1)



            

        self.get_logger().info(f"done")
        # The response to be returned is part of the interface (the part below three dashes when using interface show <name_of_interface> in CLI or in the .srv file)
        return response


# The code below runs the node and should be left as is
def main(args=None):
    rclpy.init(args=args)

    node = MyClassName()
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == "__main__":
    main()
